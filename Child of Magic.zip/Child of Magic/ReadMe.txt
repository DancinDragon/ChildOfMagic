This is the first draft of my first game called "Child Of Magic".
The assests have been created by: o_lobster
Link: https://o-lobster.itch.io/

The image used in the last scene has been created by: stockgiu/Freepik Link
https://www.freepik.com/stockgiu